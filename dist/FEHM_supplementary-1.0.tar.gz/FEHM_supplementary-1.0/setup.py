from setuptools import setup, find_packages
setup(name='FEHM_supplementary',
    version='1.0',
    packages=find_packages(),
)